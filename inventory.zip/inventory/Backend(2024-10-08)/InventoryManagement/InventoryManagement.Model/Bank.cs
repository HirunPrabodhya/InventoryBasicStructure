﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryManagement.Model
{
    public class Bank
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string BankCode { get; set; } = string.Empty;
        //normal properties
        public string IsActive { get; set; } = string.Empty;
        public int CreatedBy { get; set; } ;
        public DateTime CreatedDate { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public List<BankBranch> BankBranches { get; set; } = new List<BankBranch>();
    }
   /* public class BankEntityTypeConfiguration : IEntityTypeConfiguration<Bank>
    {
        public void Configure(EntityTypeBuilder<Bank> builder)
        {
            builder.HasKey(x => x.Id);
            //  builder.Property(x => x.Id).UseIdentityColumn();
            builder.HasIndex(x => x.Name).IsUnique();
            builder.Property(x => x.Name).HasColumnType("varchar(250)");
            builder.Property(x => x.IsActive).HasColumnType("varchar(1)"); ;
            builder.Property(x => x.CreatedBy).HasColumnType("varchar(100)");
            builder.Property(x => x.BankCode).HasColumnType("varchar(50)");
            builder.HasIndex(x => x.BankCode).IsUnique();
        }
    }*/
}
