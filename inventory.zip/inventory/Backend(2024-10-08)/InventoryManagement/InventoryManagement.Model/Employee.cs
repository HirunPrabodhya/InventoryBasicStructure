﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryManagement.Model
{
    public class Employee
    {
        public int Id { get; set; }
        public EmployeeType EmployeeType { get; set; }
        public int EmployeeTypeId { get; set; }
        public string Initials { get; set; } = string.Empty;
        public JobTitle JobTitles { get; set; }
        public int JobTitleId { get; set; }
        public string FirstName { get; set; } = string.Empty;
        public string MiddleName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string street { get; set; } = string.Empty;
        public string PhoneNumber { get; set; }
        public string MobileNumber { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public DateTime BirthDay { get; set; }
        public string NICNo { get; set; } = string.Empty;
        public EPFCompany EPFCompany { get; set; }
        public int EPFCompanyId { get; set; }
        public int EPFNumber { get; set; }
        public GenderType GenderType { get; set; }
        public int GenderTypeId { get; set; }
        public City City { get; set; }
        public int CityId { get; set; }
        public Country Country { get; set; }
        public int CountryId { get; set; }
        public EmployeeStatus EmployeeStatus { get; set; }
        public int EmpStatusId { get; set; }
        public Location Location { get; set; }
        public int LocationId { get; set; }
        public Title Title { get; set; }
        public int TitleId { get; set; }
        public DateTime EmployeementDate { get; set; }
        public DateTime TerminationDate { get; set; }
        public string IsActive { get; set; } = string.Empty;
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
