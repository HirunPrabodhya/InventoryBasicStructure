﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryManagement.Model
{
    public class SaleLedger
    {
        public int Id { get; set; }
        public Ledger? Ledger { get; set; }
        public int LedgerId { get; set; }
        public DateTime LedgerDate { get; set; }
        public string InvoiceNo { get; set; } = string.Empty;
        public Customer? Customer { get; set; }
        public int CustomerId { get; set; }
        public decimal Credit { get; set; }
        public decimal Debit { get; set; }
        public string IsActive { get; set; } = string.Empty;
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
