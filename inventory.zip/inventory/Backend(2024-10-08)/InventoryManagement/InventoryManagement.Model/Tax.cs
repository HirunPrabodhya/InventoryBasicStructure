﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryManagement.Model
{
    public class Tax
    {
        public int Id { get; set; }
        public TaxType TaxType { get; set; }
        public int TaxTypeId { get; set; }
        public string Name { get; set; } = string.Empty;
        public decimal TaxPrecentage { get; set; } // 18.9
        public string IsActive { get; set; } = string.Empty;
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
