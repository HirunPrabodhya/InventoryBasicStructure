﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryManagement.Model
{
    public class SalesHeader
    {
        public int Id { get; set; }
        public Location? Location { get; set; }
        public int LocationId { get; set; }
        public DeliveryMethod? DeliveryMethod { get; set; }
        public int DeliveryMethodId { get; set; }
        public int InvoiceNumber { get; set; }
        public DateTime SaleDate { get; set; }
        public Customer? Customer { get; set; }
        public int CustomerId { get; set; }
        public string CustomerName { get; set; } = string.Empty;
        public string CustomerAddress { get; set; } = string.Empty;
        public CustomerSaleType CustomerSaleType { get; set; }
        public int CustomerSaleTypeId { get; set; }
        public string OrderNumber { get; set; } = string.Empty;
        public int IsPriceIncludeVat { get; set; }
        public int PrintCount { get; set; }
        public string VatRegistrationNumber { get; set; } = string.Empty;
        public DateTime OrderDate { get; set; }
       
        public DateTime DeliveryDate { get; set; }
        
        public DateTime DueDate { get; set; }
        public string IsActive { get; set; } = string.Empty;
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
