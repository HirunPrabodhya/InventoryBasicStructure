﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryManagement.Model
{
    public class GoodIssuedNote
    {
        public int Id { get; set; }
        public GoodIssueType? GoodIssueType { get; set; }
        public int GoodIssueTypeId { get; set; }
        public string GRNNo { get; set; } = string.Empty;
        public DateTime GoodIssuedDate { get; set; }
        public Item? Item { get; set; }
        public int ItemId { get; set; }
        public Customer? Customer { get; set; }
        public int CustomerId { get; set; }
        public string PurchesStatus { get; set; } = string.Empty;
        public string ImportFileNumber { get; set; } = string.Empty;
        public decimal RecivedQty { get; set; }
        public string SerialNumber { get; set; } = string.Empty;
        public string IsActive { get; set; } = string.Empty;
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
