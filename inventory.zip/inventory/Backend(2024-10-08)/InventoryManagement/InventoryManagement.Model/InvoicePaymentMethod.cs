﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryManagement.Model
{
    public class InvoicePaymentMethod
    {
        public int Id { get; set; }
        public PaymentMethodType? PaymentMethodType { get; set; }
        public int PaymentMethodTypeId { get; set; }
        public string PaymentMethodReference { get; set; } = string.Empty;  
        public SalesHeader? SalesHeader { get; set; }
        public int SalesHeaderId { get; set; }
        public string InvoiceNumber { get; set; } = string.Empty;
        public decimal Amount { get; set; } //18.9
        public string IsActive { get; set; } = string.Empty;
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }

    }
}
