﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryManagement.Model
{
    public class Customer
    {
        public int Id { get; set; }
        public CustomerType CustomerType { get; set; }
        public int CutomerTypeId { get; set; }
        public string Name { get; set; } = string.Empty;
        public string PermanentAddress { get; set; } = string.Empty;
        public string ServiceAddress { get; set; } = string.Empty;
        public string InvoiceAddress { get; set; } = string.Empty;
        public string NICNo { get; set; } = string.Empty;
        public DateTime BirthDay { get; set; }
        public City City { get; set; }
        public int CityId { get; set; }
        public string PhoneNumber1 { get; set; } = string.Empty;
        public string PhoneNumber2 { get; set; } = string.Empty ;
        public string Email { get; set; } = string.Empty;
        public string PassportNumber { get; set; } = string.Empty;
        public decimal CreditLimit { get; set; } // 18.9
        public string NaviCustomerCode { get; set; } = string.Empty;
        public string NaviCustomerName { get; set; } = string.Empty;
        public string VatRegistrationNumber { get; set; } = string.Empty;
        public string SvatRegistrationNumber { get; set; } = string.Empty;
        public string LoyaltyCardNumber { get; set; } = string.Empty;
        public string IsLoyaltyMember { get; set; } = string.Empty;
        public string IsActive { get; set; } = string.Empty;
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }

    }
}
