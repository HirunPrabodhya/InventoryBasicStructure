﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryManagement.Model
{
    public class PurchesReturn
    {
        public int Id { get; set; }
        public PurchesReturnType? PurchesReturnType { get; set; }
        public int PurchesReturnTypeId { get; set; }
        public decimal PurchaseAmmount { get; set; }
        public string PurchesNumber { get; set; }
        public GoodRecievedNote GoodRecievedNote { get; set; }
        public int GoodRecievedNoteId { get; set; }
        public string IsActive { get; set; } = string.Empty;
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
