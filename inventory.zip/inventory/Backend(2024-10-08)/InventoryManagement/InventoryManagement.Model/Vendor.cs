﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryManagement.Model
{
    public class Vendor
    {
        public int Id { get; set; }
        public VendorType? VenderType { get; set; }
        public int VenderTypeId { get; set; }
        public City City { get; set; }
        public int CityId { get; set; }
        public string Name { get; set; }
        public decimal CreditPeriod { get; set; } // 18.9
        public string VenderNaviCode { get; set; } = string.Empty;
        public string VenderNaviName { get; set; } = string.Empty ;
        public string VatRegistrationNumber { get; set; } = string.Empty;
        public string VendorEmail { get; set; } = string.Empty;
        public string VendorAddress { get; set; } = string.Empty;
        public string PhoneNumber1 { get; set; } = string.Empty;
        public string PhoneNumber2 { get; set; } = string.Empty;

        public string IsActive { get; set; } = string.Empty;
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }

    }
}
