﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryManagement.Model
{
    public class GoodReturn
    {
        public int Id { get; set; }
        public GoodRecievedNote? GoodRecievedNote{ get; set; }
        public int GoodRecievedNoteId { get; set; }
        public GoodReturnType? GoodReturnType { get; set; }
        public int GoodReturnTypeId { get; set; }
        public Item Item { get; set; }
        public int ItemId { get; set; }
        public int ReturnQty { get; set; }
        public Vendor Vendor { get; set; }
        public int VendorId { get; set; }
        public int SerialNo { get; set; }
        public DateTime GoodReturnDate { get; set; }
        public string GRNNo { get; set; }
        public string IsActive { get; set; } = string.Empty;
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
