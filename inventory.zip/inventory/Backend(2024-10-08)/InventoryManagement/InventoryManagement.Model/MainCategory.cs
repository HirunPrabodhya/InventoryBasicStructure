﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryManagement.Model
{
    public class MainCategory
    {
        public int Id { get; set; }
        public MasterCategory MasterCategory { get; set; }
        public int MasterCategoryId { get; set; }
        public string MainCategoryName { get; set; } //furniture, electronic, AC, solar, food, textiles
        public string IsActive { get; set; } = string.Empty;
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
