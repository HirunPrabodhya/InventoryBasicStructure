﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryManagement.Model
{
    public class PurchesLedger
    {
        public int Id { get; set; }
        public Ledger? Ladger { get; set; }
        public int LadgerId { get; set; }
        public int GRNNo { get; set; }
        public GoodRecievedNote? GoodRecievedNote { get; set; }
        public int GRNId { get; set; }
        public Item? Item { get; set; }
        public int ItemId { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal Amount { get; set; }
        public DateTime PurchesLagerDate { get; set; }
        public PurchesMeasurementUnit? PurchesMeasurementUnit { get; set; }
        public int PurhesMeasurementUnitId { get; set; }
        public decimal VatPrecentage { get; set; }
        public decimal VatAmount { get; set; }
        public decimal DiscountPresentage { get; set; }
        public decimal DiscountAmount { get; set; }
        public decimal CreditAmount { get; set; }
        public decimal DebitAmount { get; set; }
        public string IsActive { get; set; } = string.Empty;
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
