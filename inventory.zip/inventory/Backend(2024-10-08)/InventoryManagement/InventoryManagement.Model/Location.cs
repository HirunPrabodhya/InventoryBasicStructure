﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryManagement.Model
{
    public class Location
    {
        public int Id { get; set; }
        public LocationType? LocationType { get; set; }
        public int LocationTypeId { get; set; }
        public string Name { get; set; } = string.Empty;
        public string NaviLocationCode { get; set; } = string.Empty;
        public string NaviLocationName { get; set; } = string.Empty;
        public string Street { get; set; } = string.Empty;
        public City? City { get; set; } // ask
        public int CityId { get; set; }
        public Country? Country { get; set; } // ask
        public int CountryId { get; set; } 
        public string PhoneNumber1 { get; set; } = string.Empty;
        public string PhoneNumber2 { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty ;
        public int ContactPerson { get; set; }
        public int RegionManager { get; set; }
        public int AreaManager { get; set; }

        public int ShowRoomManager { get; set; }
        public int IWH { get; set; }
        public string IsActive { get; set; } = string.Empty;
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int UpdatedBy { get; set;  }
        public DateTime UpdatedDate { get; set; }

    }
}
