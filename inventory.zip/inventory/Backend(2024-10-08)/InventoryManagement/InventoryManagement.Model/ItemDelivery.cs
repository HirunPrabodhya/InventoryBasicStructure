﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryManagement.Model
{
    public class ItemDelivery
    {
        public int Id { get; set; }
        public string InvoiceNo { get; set; } = string.Empty;
        public DateTime DeliveryDate { get; set; }
        public string DeliveryNo { get; set; } = string.Empty ;
        public string CustomerName { get; set; } = string.Empty;
        public string DeliveryAddress { get; set; } = string.Empty;
        public string CustomerMobile { get; set; } = string.Empty;
        public string CustomerPhone { get; set; } = string.Empty;
        public string Note { get; set; } = string.Empty;
        public string DriverName { get; set; } = string.Empty;
        //***//
        public int Helper1 { get; set; }
        public int Helper2 { get; set; }
        public int Helper3 { get; set; }
        public int Helper4 { get; set; }
        public string IsActive { get; set; } = string.Empty;
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
