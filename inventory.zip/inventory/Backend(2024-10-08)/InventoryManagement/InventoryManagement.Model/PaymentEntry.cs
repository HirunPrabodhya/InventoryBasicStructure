﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryManagement.Model
{
    public class PaymentEntry
    {
        public int Id { get; set; }
        public Location? Location { get; set; }
        public int LocationId { get; set; }
        public PostTerminal? PostTerminal { get; set; }
        public int PostTerminalId { get; set; }
        public SalePerson? SalePerson { get; set; }
        public int SalePersonId { get;  set; }
        public string ReciptNo { get; set; } = string.Empty;
        public PaymentMethodType? PaymentMethodType { get; set; }
        public int PaymentMethodTypeId { get; set; }
        public string PaymentMethodReference { get; set; }=string.Empty;
        public DateTime PaymentDate { get; set; }
        public decimal PaymentAmount { get; set; }
        public int IsPaymentRecived { get; set; }
        public string PaymentRecivedReferenceNo { get; set; } = string.Empty;
        public DateTime PaymentRecivedDate { get; set; }
        public decimal SettledAmount { get; set; }
        public string SettleDocumentNo { get; set; } = string.Empty;
        public decimal AdditionalPayment { get; set; }
        public decimal BankCharge { get; set; }
        public string IsActive { get; set; } = string.Empty;
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
