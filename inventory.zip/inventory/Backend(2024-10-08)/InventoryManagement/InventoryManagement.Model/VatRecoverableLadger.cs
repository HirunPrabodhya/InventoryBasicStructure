﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryManagement.Model
{
    public class VatRecoverableLadger
    {
        public int Id { get; set; }
        public GoodRecievedNote GoodRecievedNote { get; set; }
        public int GoodRecievedNoteId { get; set; }
        public string GRNNo { get; set; } = string.Empty;
        public PurchesNote PurchesNote { get; set; }
        public string PurchesNoteNo { get; set; } = string.Empty;
        public string InvoiceNo { get; set; } = string.Empty;
        public decimal VatPrecentage { get; set; }
        public decimal VatAmount { get; set; }
        public decimal TotalInvoiceValue { get; set; }
        public decimal CreditAmount { get; set; }
        public decimal DebitAmount { get; set; }
        public string IsActive { get; set; } = string.Empty;
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
