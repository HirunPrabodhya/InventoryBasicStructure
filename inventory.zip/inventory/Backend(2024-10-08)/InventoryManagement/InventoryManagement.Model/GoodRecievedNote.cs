﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryManagement.Model
{
    public class GoodRecievedNote
    {
        public int Id { get; set; }
        public GRNType? GRNType { get; set; }
        public int GRNTypeId { get; set; }
        public string GRNNo { get; set; }
        public DateTime GoodRecivedDate { get; set; }
        public Item Item { get; set; }
        public int ItemId { get; set; }
        public Vendor Vender { get; set; }
        public int VenderId { get; set; }
        public string PurchesStatus { get; set; } = string.Empty;
        public string ImportFileNumber { get; set; }
        public decimal RecivedQty { get; set; }
        public string SerialNumber { get; set; } = string.Empty;
        public string IsActive { get; set; } = string.Empty;
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
