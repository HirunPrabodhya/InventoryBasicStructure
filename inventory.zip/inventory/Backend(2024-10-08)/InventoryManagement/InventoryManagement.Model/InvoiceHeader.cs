﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryManagement.Model
{
    public class InvoiceHeader
    {
        public int Id { get; set; }
        public string SaleInvoiceNumber { get; set; } = string.Empty;
        public string SellToCustomer { get; set; } = string.Empty;
        public string BillToCustomer { get; set; } = string.Empty;
        public string BillToName { get; set; } = string.Empty;
        public string BillToAddress { get; set; } = string.Empty;
        public DateTime DeliveryDate { get; set; }
        public Location? Location { get; set; }
        public int LocationId { get; set; }
        public SalePerson? SalePerson { get; set; }
        public int SalePersonId { get; set; }
        public DeliveryMethod DeliveryMethod { get; set; }
        public int DeliveryMethodId { get; set; }
        public decimal Amount { get; set; }
        public string MobileNumber { get; set; } = string.Empty;
        public string PhoneNumber { get; set; } = string.Empty;
        public string OrderNumber { get; set; } = string.Empty;
        public string IsActive { get; set; } = string.Empty;
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
