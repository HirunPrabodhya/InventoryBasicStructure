﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryManagement.Model
{
    public class Item
    {
        public int Id { get; set; }
        public Measurement? Measurement { get; set; }
        public int MeasurementUnitId { get; set; }
        public ItemSizeType? ItemSizeType { get; set; }
        public int ItemSizeTypeId { get; set; }
        public ItemCapacityMeasurement? ItemCapacityMeasurement { get; set; }
        public int ItemCapacityMeasurementId { get; set; }
        public SameMeasurmentUnit? SameMeasurmentUnit { get; set; }
        public int SameMeasurmentUnitId { get; set; }
        public PurchesMeasurementUnit? PurchesMeasurementUnit { get; set; }
        public int PurchesMeasurementUnitId { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty ;
        public string ItemCode { get; set; } = string.Empty;
        public string ItemDimention { get; set; } = string.Empty;
        public decimal ItemNetWeight { get; set; }
        public decimal ItemGrossWeight { get; set; }
        public decimal NumberOfUnit { get; set; }
        public decimal NumberOfPackages { get; set; } // box = 3
        public decimal Depth { get; set; }// 18.9
        public decimal Weight { get; set; }// 18.9
        public decimal Height { get; set; }// 18.9
        public string HSCode { get; set; } = string.Empty;
        public decimal Cube { get; set; } // 18.9
        public string NaviItemCode { get; set; } = string.Empty ;
        public string NaviItemName { get; set; } = string.Empty;
        public string IsLoyaltyPointApplicable { get; set; } = string.Empty;
        public string IsActive { get; set; } = string.Empty;
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
