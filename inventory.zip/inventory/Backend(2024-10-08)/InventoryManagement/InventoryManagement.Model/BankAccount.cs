﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryManagement.Model
{
    public class BankAccount
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string BankAccountNumber { get; set; } = string.Empty;
        public int MinBalance { get; set; } = 0;
        public BankBranch? BankBranch { get; set; }
        public int BankBranchId { get; set; }
        public MainCategory? MainCategory { get; set; }
        public int MainCategoryId { get; set; }
        public Location? Location { get; set; }
        public int LocationId { get; set; } //showroom location
        public string SWIFTCode { get; set; } = string.Empty;
        public string IsActive { get; set; } = string.Empty;
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }

    }
}
