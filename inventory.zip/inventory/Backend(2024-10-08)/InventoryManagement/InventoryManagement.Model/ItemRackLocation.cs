﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryManagement.Model
{
    public class ItemRackLocation
    {
        public int Id { get; set; }
        public Item? Item { get; set; }
        public int ItemId { get; set; }
        public int RacNo { get; set; }
        public int RowNo { get; set; }
        public int BinNo { get; set; }
        public string IsActive { get; set; } = string.Empty;
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
